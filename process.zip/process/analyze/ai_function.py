'''
here a fake time consuming task for dev
'''
import os
import inspect
import time
import random

ALLOWED_EXTENSION = ('.tif', '.jpg', '.jpeg')  # lower, jpg/.jpeg for test purpose


def time_consuming_task(fp, task_id, callback):
    if not isinstance(fp, str):
        raise TypeError

    if not os.path.exists(fp):
        raise FileNotFoundError

    if not os.path.isdir(fp):
        raise ValueError

    if not isinstance(task_id, int):
        raise TypeError

    if task_id < 1:
        raise ValueError

    if not inspect.isfunction(callback):
        raise TypeError

    # fake process here
    t = 0
    while True:
        if t == 10:
            break
        time.sleep(1)
        t += 1

    callback(task_id, random.choice([2, 3]))
    # 2 -- success
    # 3 -- failed

